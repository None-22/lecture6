﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara_hageb_lect6
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap mybitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            int x=50, y=50 ,size=100;
            //int x,y;
            //for (x = 0; x < 100; x++)
            //{
            //    y = x;
            //    mybitmap.SetPixel(x, y, Color.Red);

            //}
            //pictureBox1.Image = mybitmap;
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    mybitmap.SetPixel(x + i, y + j, Color.DarkGreen);
            pictureBox1.Image = mybitmap;
 
    }

        private void Form4_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
        }
    }
}
